module.exports = {
    dbURI: 'mongodb://localhost:27017/doctorAppointmentDB',
    port: 3000,
  };
  